import React from 'react'
import { NavLink, NavLink as RouterLink } from 'react-router-dom'
import Logo from '../Image/logo.png'
import { Search2Icon } from '@chakra-ui/icons'
import { Box, Container, Flex, HStack, Image, Input, Text } from '@chakra-ui/react'




const Navbar = () => {

    const AllLinks = [
        { path: '/women', title: 'WOMEN' },
        { path: '/shoes', title: 'SHOES' },
        { path: '/handbags', title: 'HANDBAGS' },
        { path: '/jwellery', title: 'JWELLERY & ACCESSORIES' },
        { path: '/men', title: 'MEN' },
        { path: '/kids', title: 'KIDS' },
        { path: '/', title: 'HOME' },
        { path: '/sale', title: 'SALE' },
        { path: '/designers', title: 'DESIGNERS' },
        { path: '/editorial', title: 'EDITORIAL' },
        { path: '/gifts', title: 'GIFTS' },
    ]


    return (
        <Container maxW='100%' h='auto' border='1px solid red'>
            <Flex justifyContent='flex-end'>
                <Box h='40px' border='1px solid blue' w='22%' display='flex' justifyContent='space-around'>
                    <Box borderRight='1px solid grey' w='100px' h='20px' m='auto'>
                        <RouterLink>
                            <Text fontSize={12}>Store & Events</Text>
                        </RouterLink>
                    </Box>
                    <Box borderRight='1px solid grey' w='110px' h='20px' m='auto'>
                        <RouterLink>
                            <Text fontSize={12}>Shopping Services</Text>
                        </RouterLink>
                    </Box>
                    <Box borderRight='1px solid grey' w='100px' h='20px' m='auto' display='flex'>
                        <RouterLink>
                            <HStack>
                                <Image m='-2px 10px' src='https://assets.bloomingdales.com/feature/header-bcom/latest/images/flags/IN.png' />
                                <Text fontSize={12}>INR</Text>
                            </HStack>
                        </RouterLink>
                    </Box>
                </Box>
            </Flex>
            {/* Logo Section & Search bar */}
            <hr />
            <Flex justifyContent='space-between'>
                <Box mt={5} border='1px solid red'>
                    <Image src={Logo} w='100%' h='60px' m='auto 1.2rem' />
                </Box>
                <Box mt={5}>
                    <Input w='350px' ></Input>
                </Box>
            </Flex>
            {/* Navlinks */}
            <Flex justifyContent='space-around' mt={5}>
                {
                    AllLinks.map((item) => (
                        <NavLink key={item.path} to={item.path}>
                            <Text fontSize={14} fontWeight='600'>{item.title}</Text>
                        </NavLink>
                    ))
                }
            </Flex>
        </Container>
    )
}

export default Navbar