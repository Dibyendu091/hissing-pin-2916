import React from 'react'

const Handbags = () => {
  return (
    <div>Handbags</div>
  )
}

export default Handbags