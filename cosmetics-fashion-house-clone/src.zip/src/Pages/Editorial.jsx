import React from 'react'

const Editorial = () => {
  return (
    <div>Editorial</div>
  )
}

export default Editorial