import React from 'react'

const Jwellery = () => {
  return (
    <div>Jwellery</div>
  )
}

export default Jwellery