import React from 'react'

const Men = () => {
  return (
    <div>Men</div>
  )
}

export default Men