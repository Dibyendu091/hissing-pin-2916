import React from 'react'

const Kids = () => {
  return (
    <div>Kids</div>
  )
}

export default Kids