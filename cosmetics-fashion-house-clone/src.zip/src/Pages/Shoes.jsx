import React from 'react'

const Shoes = () => {
  return (
    <div>Shoes</div>
  )
}

export default Shoes