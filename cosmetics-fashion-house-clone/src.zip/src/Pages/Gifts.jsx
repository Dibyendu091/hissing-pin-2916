import React from 'react'

const Gifts = () => {
  return (
    <div>Gifts</div>
  )
}

export default Gifts